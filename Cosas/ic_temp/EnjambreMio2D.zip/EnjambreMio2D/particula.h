class Particula{
	
	vector <float> pos,mejorPos,vel;
	int n;
	float c1=0.5,c2=0.01;
public:
	
	Particula(){pos.clear(); mejorPos.clear(); vel.clear();}
	Particula(int cant){
		pos.clear(); mejorPos.clear(); vel.clear();
		float aux=0;
		for(int i=0;i<cant;i++){
			// ************************ Definimos el rango de valores
			aux=rand()/double(RAND_MAX)*200-100;
			pos.push_back(aux);
			mejorPos.push_back(aux);
			vel.push_back(0.0);
		}
		n=cant;
	}

	void returnPos(vector<float> &bestPos){
		bestPos=mejorPos;
	}
	
	float funcionPos(){
		return pow(pow(pos[0],2)+pow(pos[1],2),0.25)*(pow(sin(50*(pow(pow(pos[0],2)+pow(pos[1],2),0.1))),2)+1);
	}
	float funcionMejorPos(){
		return pow(pow(mejorPos[0],2)+pow(mejorPos[1],2),0.25)*(pow(sin(50*(pow(pow(mejorPos[0],2)+pow(mejorPos[1],2),0.1))),2)+1);
	}
	
	void actualizarVelocidad(vector <float>best){
		float r1 =rand()/float(RAND_MAX),
			r2 =rand()/float(RAND_MAX);
		for(int i=0;i<n;i++){
			vel[i]=vel[i]+c1*r1*(mejorPos[i]-pos[i])+c2*r2*(best[i]-pos[i]);
		}
	}
	
	void actualizarPos(){
		for(int i=0;i<n;i++){
			pos[i]=pos[i]+vel[i];
		}
		if(pos[0]<-100)
			pos[0]=-100;
		if(pos[0]>100)
			pos[0]=100;
			
		actualizarY();
	}
	
	float actualizarY(){
		if(funcionPos()<funcionMejorPos())
			mejorPos=pos;
	}
	
	void show(){
		cout<<"pos "<<pos[0]<<"  "<<pos[1]<<"  mejorPos  "<<mejorPos[0]<<mejorPos[1]<<endl;
	}
	
	
	void dibParticula(){
		
		glBegin(GL_POINTS);
			glVertex2f(pos[0],pos[1]);
		glEnd();
		
	}
	
};
