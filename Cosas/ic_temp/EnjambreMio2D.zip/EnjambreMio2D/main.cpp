

#include <GL/glut.h>
#include <iostream>
#include <vector>
#include <cmath>

using namespace std;

#include "particula.h"
#include "enjambre.h"


// ***************** VARIABLES GLOBALES *****************
Enjambre enja;

int w=800,h=750;


void circulo_Bresenham(int xc, int yc, int r) {
	
	
	glBegin(GL_POINTS);
	if (!r){
		glVertex2i(xc,yc);
		glEnd();
		return;
	}
	
	int x=0, y=r, h=1-r;
	while (y>x){
		glVertex2i( x+xc, y+yc);
		glVertex2i( x+xc,-y+yc);
		glVertex2i(-x+xc, y+yc);
		glVertex2i(-x+xc,-y+yc);
		
		glVertex2i( y+xc, x+yc);
		glVertex2i( y+xc,-x+yc);
		glVertex2i(-y+xc, x+yc);
		glVertex2i(-y+xc,-x+yc);
		//cout << x << "," << y << "\n";
		if (h>=0){ // SE
			h+=((x-y)<<1)+5;
			y--;
		}
		else { // E
			h+=(x<<1)+3;
		}
		x++;
	}
	// x==y => no hace falta intercambiar
	glVertex2i( x+xc, y+yc);
	glVertex2i( x+xc,-y+yc);
	glVertex2i(-x+xc, y+yc);
	glVertex2i(-x+xc,-y+yc);
	glEnd();
	//cout << endl;
}



void dibRectas(){
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glColor3f(.0,1.0,.0);
	glLineWidth(2);
	glBegin(GL_LINES);
	glVertex2f(-100,0);
	glVertex2f(100,0);
	glVertex2f(0,-100);
	glVertex2f(0,100);
	glEnd();
	glPopAttrib();
}

void dibCirculos(int cantidad){
	float paso=100.0/float(cantidad),valor=0,x=0;
	float color1=0,color2=0;
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPointSize(1.3);
	
	for(int i=0;i<cantidad;i++){
		x+=paso;
		valor=pow(pow(x,2),0.25)*(pow(sin(50*(pow(pow(x,2),0.1))),2)+1);
		// valor [0,25] hago el mapeo de los colores
		float max=12.5;
		if(valor<max){
			color1=valor/max;
			color2=1-valor/max;
			glColor3f(.0,color1,color2);
		}else{
			valor-=max;
			color1=valor/max;
			color2=1-valor/max;
			glColor3f(color1,color2,.0);
		}
		
		circulo_Bresenham(0,0,int(x));
		
	}
	
	glPopAttrib();
}

void display_cb() {
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0,0,1); glLineWidth(3);
	glPointSize(4);
	glLineWidth(1);
	glPushMatrix();
		
		glTranslated(w/2,h/2,0);
		glScaled(3,3,1);
		dibRectas();
		dibCirculos(100);
		
		glColor3f(.0,0.,0.);
		enja.dibEnjambre();
		
	glPopMatrix();
	glutSwapBuffers();
}

void reshape_cb (int w, int h) {
	if (w==0||h==0) return;
	glViewport(0,0,w,h);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluOrtho2D(0,w,0,h);
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity ();
}




void Special_cb(int key, int xm=0, int im=0){
	if(key ==GLUT_KEY_F1)
		exit(EXIT_SUCCESS);
}


void Keyboard_cb(unsigned char key,int xx=0,int yy=0) {	
	switch(key){
	case 'q':{
		enja.evaluarTodos();
		break;
	}
	}
	display_cb();
}

void initialize() {
	glutInitDisplayMode (GLUT_RGBA|GLUT_DOUBLE);
	glutInitWindowSize (w,h);
	glutInitWindowPosition (100,100);
	glutCreateWindow ("Ventana OpenGL");
	glutDisplayFunc (display_cb);
	glutReshapeFunc (reshape_cb);
	glClearColor(1.f,1.f,1.f,1.f);
	glutKeyboardFunc(Keyboard_cb);
	glutSpecialFunc(Special_cb);
}

int main (int argc, char **argv) {
	srand(time(NULL));
	
	enja=Enjambre(20,2);
	
	glutInit (&argc, argv);
	initialize();
	glutMainLoop();
	return 0;
}
